﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using MatchesApi.Enum;

namespace MatchesApi.Entities
{
    public class Match
    {
        
        public Match()
        {
            MatchOdds = new List<MatchOdds>();
        }
        public int ID { get; set; }
        //[Required(ErrorMessage = "The field with name {0} is required")]
        //[StringLength(10)]
        public string Description { get; set; }
        public DateTime MatchDate { get; set; }
        public DateTime MatchTime { get; set; }
        public string TeamA { get; set; }
        public string TeamB { get; set; }
        public  Sport sport{ get; set; }

        public IList<MatchOdds> MatchOdds { get; set; }
    }
}
