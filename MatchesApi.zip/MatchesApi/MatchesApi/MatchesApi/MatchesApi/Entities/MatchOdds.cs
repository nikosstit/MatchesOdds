﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace MatchesApi.Entities
{
    public class MatchOdds
    {
        public int ID { get; set; }
        [ForeignKey("Customer")]
        public int MatchId { get; set; }
        public string Specifier { get; set; }
        public string Odd { get; set; }

    }
}
