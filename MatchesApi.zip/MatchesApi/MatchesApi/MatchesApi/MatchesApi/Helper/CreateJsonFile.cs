﻿using MatchesApi.Entities;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace MatchesApi.Helper
{
    /// <summary>
    /// This class is responsible to create and save data into json files
    /// </summary>
    public static class CreateJsonFile
    {
        public static void Create(Match match)
        {

            Match jsonMatch = new Match();
            jsonMatch.ID = match.ID;
            //jsonMatch.Name = match.Name;
            string JSONresult = JsonConvert.SerializeObject(jsonMatch);
            string path = @"C:\json\match.json";
            if (File.Exists(path))
            {
                File.Delete(path);
                using (var tw = new StreamWriter(path, true))
                {
                    tw.WriteLine(JSONresult.ToString());
                    tw.Close();
                }
            }
            else if (!File.Exists(path))
            {
                 using (var tw = new StreamWriter(path, true))
                {
                     tw.WriteLine(JSONresult.ToString());
                     tw.Close();
                 }
              }
        }
    }
}
