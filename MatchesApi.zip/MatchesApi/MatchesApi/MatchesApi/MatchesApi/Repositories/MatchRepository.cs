﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MatchesApi.Entities;
using Microsoft.EntityFrameworkCore;

namespace MatchesApi.Repositories
{
    public class MatchRepository : IMatchRepository
    {
        private readonly ApplicationDbContext _context;

        public MatchRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        /// <summary>
        /// Create a Match, with Possible Odds Included 
        /// </summary>
        /// <param name="match">The macth entity from Entities folder, with a list od Odds</param>
        /// <returns></returns>
        public async Task<Match> Create(Match match)
        {
            _context.Matches.Add(match);
            await _context.SaveChangesAsync();
            return match;
        }

        /// <summary>
        /// Delete a Match, with Odds Included 
        /// </summary>
        /// <param name="id">Match ID</param>
        /// <returns></returns>
        public async Task Delete(int id)
        {
            var matchToDelete = await _context.Matches.FindAsync(id);
            _context.Matches.Remove(matchToDelete);
            await _context.SaveChangesAsync();
        }

        /// <summary>
        /// Present a List With all Matches And Odds Lists Including Per Match
        /// </summary>
        /// <returns></returns>
        public async Task<IEnumerable<Match>> Get()
        {
            var matches = _context.Matches
           .Include(c => c.MatchOdds)
           .AsNoTracking();
            return await matches.ToListAsync();
        }

        /// <summary>
        /// Present a Match with Odds Included as a List
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<Match> Get(int id)
        {
           var match = _context.Matches
          .Include(c => c.MatchOdds)
          .AsNoTracking()
          .FirstOrDefaultAsync(x => x.ID == id);
           return await match; 
        }

        /// <summary>
        /// Update a Match Including Odds
        /// </summary>
        /// <param name="match">The macth entity from Entities folder</param>
        /// <returns></returns>
        public async Task Update(Match match)
        {
            _context.Entry(match).State = EntityState.Modified;
            await _context.SaveChangesAsync();
        }
    }
}
