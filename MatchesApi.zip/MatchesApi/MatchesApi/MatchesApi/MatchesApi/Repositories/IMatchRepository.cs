﻿using MatchesApi.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MatchesApi.Repositories
{
    public interface IMatchRepository
    {
        Task<IEnumerable<Match>> Get();

        Task<Match> Get(int id);

        Task<Match> Create(Match match);
        Task Update(Match match);
        Task Delete(int id);
    }
}
