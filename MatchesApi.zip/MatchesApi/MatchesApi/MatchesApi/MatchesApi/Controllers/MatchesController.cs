﻿
using MatchesApi.Entities;
using MatchesApi.Repositories;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace MatchesApi
{
    [Route("api/matches")]
    [ApiController]
    public class MatchesController: ControllerBase
    {
        private readonly ILogger<MatchesController> logger;
        private readonly IMatchRepository _matchRepository;
        public MatchesController(ILogger<MatchesController> logger, IMatchRepository matchRepository)
        {
            this.logger = logger;
            _matchRepository = matchRepository;
        }

        /// <summary>
        /// Present a List With all Matches And Odds Lists Including Per Match
        /// </summary>
        /// <returns>matches</returns>
        [HttpGet]
        public async Task<IEnumerable<Match>> GetMatches()
        {
            return await _matchRepository.Get();
        }

        /// <summary>
        /// Present a Match with Odds Included as a List
        /// </summary>
        /// <param name="ID"></param>
        /// <returns>match</returns>
        [HttpGet("{ID}")] 
        public async Task<ActionResult<Match>> GetMatches(int ID)
        {
            var match = await _matchRepository.Get(ID);
            if (match == null)
            {
                //logger.LogWarning($"Match with {Id} not found");
                return NotFound();
            }
            return match;
        }

        /// <summary>
        ///  Create a Match, with Possible Odds Included 
        /// </summary>
        /// <param name="match">The macth entity from Entities folder, contains a list od Odds</param>
        /// <returns>match</returns>
        [HttpPost]
        public async Task<ActionResult<Match>> PostMatches([FromBody] Match match)
        {
            var newMatch = await _matchRepository.Create(match);
            return CreatedAtAction(nameof(GetMatches), new { id = newMatch.ID }, newMatch);
        }

        /// <summary>
        /// Update a Match Including Odds
        /// </summary>
        /// <param name="ID"></param>
        /// <param name="match">The macth entity from Entities folder, contains a list od Odds</param>
        /// <returns>match</returns>
        [HttpPut("{ID}")]
        public async Task<ActionResult> PutMatches(int ID, [FromBody] Match match)
        {
            if (ID != match.ID)
            {
                return BadRequest();
            }
            await _matchRepository.Update(match);
            return CreatedAtAction(nameof(GetMatches), new { id = match.ID }, match);
        }

        /// <summary>
        /// Delete a Match, with Odds Included 
        /// </summary>
        /// <param name="id">Match ID</param>
        /// <returns>No Content</returns>
        [HttpDelete("{id}")]
        public async Task<ActionResult> Delete(int id)
        {
            var matchToDelete = await _matchRepository.Get(id);
            if (matchToDelete == null)
                return NotFound();

            await _matchRepository.Delete(matchToDelete.ID);
            return NoContent();
            
        }

    }
}
