﻿using JetBrains.Annotations;
using MatchesApi.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;

namespace MatchesApi
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext([NotNullAttribute] DbContextOptions options) : base(options)
        {   //Check the DB connection
            Database.EnsureCreated();
        }

        public DbSet<Match> Matches { get; set; }
        public DbSet<MatchOdds> MatchOdds { get; set; }

        //protected override void OnModelCreating(ModelBuilder modelBuilder)
        //{
        //    // configures one-to-many relationship
        //    modelBuilder.Entity<Match>()
        //        .HasRequired<MatchOdds>(mo => mo.)
        //        .WithMany(m =>m.)
        //        .HasForeignKey<int>(s => s.CurrentGradeId);
        //}
    }
}

